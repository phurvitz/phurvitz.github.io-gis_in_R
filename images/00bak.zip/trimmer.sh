#!/usr/bin/bash
ls -1 *png | sed "s|\(.*\)|magick convert \"\1\" -trim \"\1\"|"|sh
